-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: library
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `programlist`
--

DROP TABLE IF EXISTS `programlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `programlist` (
  `ProgramNum` int(20) NOT NULL,
  `LibraryName` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `PhoneNum` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `Address` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `ProgramName` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `Day` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `Time` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `Age` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `Max` int(11) DEFAULT NULL,
  `Place` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `Current` int(11) DEFAULT NULL,
  PRIMARY KEY (`ProgramNum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programlist`
--

LOCK TABLES `programlist` WRITE;
/*!40000 ALTER TABLE `programlist` DISABLE KEYS */;
INSERT INTO `programlist` VALUES (1,'청주장난감도서관','02-918-8080','충청북도 청주시 서원구 충북대학교 내 청주장난감도서관','키즈 체형교정 발레','월','16:30~17:20','6~7세',18,'3층 대강당',2),(2,'청주장난감도서관','02-918-8080','충청북도 청주시 서원구 충북대학교 내 청주장난감도서관','신나는 퍼포먼스 미술놀이터','화','14:50~15:30','0~1세',15,'3층 대강당',1),(3,'청주장난감도서관','02-918-8080','충청북도 청주시 서원구 충북대학교 내 청주장난감도서관','신나는 퍼포먼스 미술놀이터','화','16:00~16:50','5~7세',15,'3층 대강당',0),(4,'청주장난감도서관','02-918-8080','충청북도 청주시 서원구 충북대학교 내 청주장난감도서관','스마트레고','금','15:30~16:20','4~5세',12,'2층 쿠킹룸',0),(5,'청주장난감도서관','02-918-8080','충청북도 청주시 서원구 충북대학교 내 청주장난감도서관','스마트레고','금','16:30~17:20','6~7세',12,'2충 쿠킹룸',0),(6,'청주장난감도서관','02-918-8080','충청북도 청주시 서원구 충북대학교 내 청주장난감도서관','키가쑥쑥 신나는요리','화','15:30~16:20','5~7세',3,'2층 쿠킹룸',3),(7,'청주장난감도서관','02-918-8080','충청북도 청주시 서원구 충북대학교 내 청주장난감도서관','아빠와 함께하는 요리','토','12:20~13:10','4~6세',12,'2층 쿠킹룸',0),(8,'청주장난감도서관','02-918-8080','충청북도 청주시 서원구 충북대학교 내 청주장난감도서관','텀블키즈 신바람놀이 ','토','10:50~11:30','3~4세',15,'3층 대강당',0);
/*!40000 ALTER TABLE `programlist` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-12 15:35:35
