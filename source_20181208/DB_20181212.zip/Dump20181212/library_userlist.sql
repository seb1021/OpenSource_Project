-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: library
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `userlist`
--

DROP TABLE IF EXISTS `userlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `userlist` (
  `IDNumber` int(11) NOT NULL AUTO_INCREMENT,
  `LibraryName` text CHARACTER SET utf8 COLLATE utf8_bin,
  `PhoneNum` text CHARACTER SET utf8 COLLATE utf8_bin,
  `Name` text CHARACTER SET utf8 COLLATE utf8_bin,
  `ChildName` text CHARACTER SET utf8 COLLATE utf8_bin,
  `ChildAge` int(11) DEFAULT NULL,
  `Toy` text CHARACTER SET utf8 COLLATE utf8_bin,
  `Issue` text CHARACTER SET utf8 COLLATE utf8_bin,
  `Program` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDNumber`)
) ENGINE=InnoDB AUTO_INCREMENT=8778 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userlist`
--

LOCK TABLES `userlist` WRITE;
/*!40000 ALTER TABLE `userlist` DISABLE KEYS */;
INSERT INTO `userlist` VALUES (2018,'청주도서관','010-1234-5678','홍길동','홍길순',3,'','',1),(2019,'청주도서관','010-1234-5679','김철수','최성현',4,'28','',NULL),(2020,'청주도서관','010-1234-5680','김철수','김성태',5,'1','',1),(2021,'청주도서관','010-1234-5681','박초희','정승제',6,'','',NULL),(2022,'청주도서관','010-1234-5682','김하나','이다지',7,'','',NULL),(2023,'청주도서관','010-1234-5683','이미정','이디야',3,'','',2),(2024,'청주도서관','010-1234-5684','오연정','북경탕',4,'28','',NULL),(2025,'청주도서관','010-1234-5685','임두이','배수지',5,'','',NULL),(2026,'청주도서관','010-1234-5686','강재구','손나은',6,'','',NULL),(2027,'청주도서관','010-1234-5687','선유진','장동건',7,'','',NULL),(2028,'청주도서관','010-1234-5688','이유진','윤보미',0,'','',NULL),(2029,'청주도서관','010-1234-5689','김나라','박초롱',1,'','',NULL),(2030,'청주도서관','010-1234-5690','최승리','차학연',2,'','',NULL),(2031,'청주도서관','010-1234-5691','김제니','차태현',3,'','',NULL),(3333,'청주도서관',NULL,'하하하','호호호',5,NULL,NULL,NULL),(5555,'청주도서관','010-0000-0000','사이다','콜라',4,NULL,NULL,NULL),(8777,'청주도서관','010-9876-5432','레드벨벳','아이린',5,NULL,NULL,NULL);
/*!40000 ALTER TABLE `userlist` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-12 15:33:03
